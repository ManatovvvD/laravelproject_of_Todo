<?php $__env->startSection('content'); ?>
    
<a href="/todos">Visit to my todos </a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Todos\resources\views/welcome.blade.php ENDPATH**/ ?>